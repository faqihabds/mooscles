/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Prawira
 */
// Kelas Person (Induk)
public class Person extends Account{
    private String name;
    private String gender;
    private int age;
    private double weight; // Berat badan dalam kilogram
    private double height; // Tinggi badan dalam sentimeter


    @Override
    public String getUsername() {
        return super.getUsername(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
     @Override
    public String getEmail() {
        return super.getEmail(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    @Override
    public String getPassword() {
        return super.getPassword(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }


    public double getHeight() {
        return height;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void setHeight(double height) {
        this.height = height;
    }
    
//    public void SaveInputEdit(JTextField nameInputEdit, ButtonGroup genderButtonGroupEdit, JTextField ageInputEdit, JTextField heightInputEdit, JTextField heightInputEdit0, JLabel name, JLabel gender, JLabel age, JLabel weight, JLabel height) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
}
